from typing import TypedDict


class Ponto(TypedDict):
    lat: float
    lon: float

#coordenadas e intervalo
LAT_MIN = -25
LAT_MAX = -19

LON_MIN = -54
LON_MAX = -44

PASSO = 0.5


def gerar_grade() -> list[Ponto]:

    pontos: list[Ponto] = []

    lat = LAT_MIN
    while lat <= LAT_MAX:

        lon = LON_MIN
        while lon <= LON_MAX:

            pontos.append({
                "lat": round(lat, 4),
                "lon": round(lon, 4),
            })

            lon += PASSO

        lat += PASSO

    return pontos