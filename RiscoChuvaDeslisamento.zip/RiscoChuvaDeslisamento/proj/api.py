import os
import httpx
import joblib
from datetime import date as date_type, datetime, timedelta
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from cache import ler_cache, salvar_cache
from grade import gerar_grade 

PRECTOTCORR_FILL_VALUE = -999  # valor que a NASA usa quando não tem dado pro dia/local

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def parse_eventos(resposta_eonet: dict) -> list[dict]:
    eventos_parseados = []

    for evento in resposta_eonet.get("events", []):
        categorias = evento.get("categories", [])
        categoria = categorias[0]["title"] if categorias else None

        geometria = evento.get("geometry", [])
        ultimo_ponto = geometria[-1] if geometria else None

        if ultimo_ponto:
            lon, lat = ultimo_ponto["coordinates"]  # GeoJSON: [lon, lat]
            data = ultimo_ponto.get("date")
        else:
            lon, lat, data = None, None, None

        eventos_parseados.append(
            {
                "id": evento.get("id"),
                "title": evento.get("title"),
                "category": categoria,
                "date": data,
                "lat": lat,
                "lon": lon,
                "closed": evento.get("closed") is not None,
            }
        )

    return eventos_parseados



# ================================================================
# MODELO DE RISCO DE DESLIZAMENTO
# ================================================================
MODELO_PATH = os.path.join(os.path.dirname(__file__), "modelo_deslizamento.joblib")
_modelo_cache = None


def carregar_modelo():
    global _modelo_cache
    if _modelo_cache is None:
        _modelo_cache = joblib.load(MODELO_PATH)
    return _modelo_cache


async def buscar_precipitacao(
    lat: float,
    lon: float,
    start: str,
    end: str,
    usar_cache: bool = True,
) -> list[dict] | dict:
    """Chuva diária da NASA POWER entre start e end (AAAAMMDD).

    Reaproveita o cache em disco do projeto de chuva. Só grava no cache
    quando a janela veio completa, para não "congelar" dados recentes que
    a NASA ainda não publicou.
    """
    if usar_cache:
        em_cache = ler_cache(lat, lon, start, end)
        if em_cache is not None and em_cache.get("daily"):
            return em_cache["daily"]

    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(30)) as client:
            resposta = await client.get(
                "https://power.larc.nasa.gov/api/temporal/daily/point",
                params=params,
            )
    except httpx.HTTPError:
        return {"mensagem": "Não foi possível conectar à NASA POWER."}

    if not resposta.is_success:
        return {"mensagem": "Problemas no retorno da API NASA POWER"}

    dados = (
        resposta.json()
        .get("properties", {})
        .get("parameter", {})
        .get("PRECTOTCORR", {})
    )

    daily = [
        {"date": data, "precipitation_mm": valor}
        for data, valor in dados.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]

    dias_pedidos = (
        datetime.strptime(end, "%Y%m%d") - datetime.strptime(start, "%Y%m%d")
    ).days + 1

    if usar_cache and len(daily) == dias_pedidos:
        salvar_cache(lat, lon, start, end, {"lat": lat, "lon": lon, "daily": daily})

    return daily


def somar_precipitacao(dados: list[dict], quantidade_dias: int) -> float:
    """Soma os últimos N dias de chuva, como no treinamento do modelo."""
    valores = [
        float(item["precipitation_mm"])
        for item in dados[-quantidade_dias:]
        if item.get("precipitation_mm") is not None
    ]
    return round(sum(valores), 2)


JANELA_DIAS = 14  # o modelo foi treinado com os 14 dias anteriores ao evento


async def criar_features_risco(lat: float, lon: float, data_referencia) -> dict:
    """Calcula 1d/3d/7d/14d a partir dos 14 dias ANTERIORES à data de referência.

    Devolve as features ou, se não der, um dict {"mensagem": ...}.
    """
    data_final = data_referencia - timedelta(days=1)
    data_inicial = data_referencia - timedelta(days=JANELA_DIAS)

    dados = await buscar_precipitacao(
        lat,
        lon,
        data_inicial.strftime("%Y%m%d"),
        data_final.strftime("%Y%m%d"),
    )

    if isinstance(dados, dict):  # erro da NASA
        return dados

    dados = sorted(dados, key=lambda item: item["date"])

    if len(dados) < JANELA_DIAS:
        return {
            "mensagem": (
                f"A NASA POWER ainda não tem os {JANELA_DIAS} dias de chuva anteriores a "
                f"{data_referencia.strftime('%d/%m/%Y')} (recebi {len(dados)}). "
                "Escolha uma data um pouco mais antiga; os dados costumam ter alguns dias de atraso."
            )
        }

    return {
        "precipitation_1d": somar_precipitacao(dados, 1),
        "precipitation_3d": somar_precipitacao(dados, 3),
        "precipitation_7d": somar_precipitacao(dados, 7),
        "precipitation_14d": somar_precipitacao(dados, 14),
    }


@app.get("/predict_risk")
async def predict_risk(
    lat: float = Query(..., description="Latitude da cidade"),
    lon: float = Query(..., description="Longitude da cidade"),
    date: str = Query(..., description="Data de referência no formato AAAA-MM-DD"),
):
    """
    Une a chuva da NASA POWER com o modelo Random Forest treinado
    no projeto de machine learning.
    """
    try:
        modelo_data = carregar_modelo()
    except FileNotFoundError:
        return {"mensagem": "Modelo de risco não encontrado."}

    try:
        data_referencia = datetime.fromisoformat(date).date()
    except ValueError:
        return {"mensagem": "Data inválida. Use o formato AAAA-MM-DD."}

    features = await criar_features_risco(lat, lon, data_referencia)

    if "mensagem" in features:
        return features

    valores = [[
        features["precipitation_1d"],
        features["precipitation_3d"],
        features["precipitation_7d"],
        features["precipitation_14d"],
    ]]

    modelo = modelo_data["random_forest"]
    probabilidade = float(modelo.predict_proba(valores)[0][1])
    predicao = int(probabilidade >= 0.5)

    if probabilidade < 0.30:
        nivel = "baixo"
    elif probabilidade < 0.60:
        nivel = "moderado"
    else:
        nivel = "alto"

    return {
        "lat": lat,
        "lon": lon,
        "date": date,
        **features,
        "landslide_probability": round(probabilidade, 4),
        "landslide_probability_percent": round(probabilidade * 100, 1),
        "prediction": predicao,
        "risk_level": nivel,
        "model": "Random Forest",
        "disclaimer": (
            "Estimativa experimental baseada somente em precipitação. "
            "Não substitui alertas oficiais nem considera, por exemplo, "
            "declividade, solo, drenagem ou ocupação do terreno."
        ),
    }

# ================================================================
# FRONTEND: a própria API entrega a página, então basta um comando
#   uvicorn api:app --reload   ->   http://127.0.0.1:8000
# (abrir o index.html por file:// impede o fetch dos dados de chuva)
# ================================================================
PASTA = os.path.dirname(os.path.abspath(__file__))
ARQUIVOS_PUBLICOS = {
    "/app": "index.html",
    "/index.html": "index.html",
    "/script.js": "script.js",
    "/style.css": "style.css",
    "/precipitacao_grade.json": "precipitacao_grade.json",
}


def _rota_arquivo(nome_arquivo: str):
    async def enviar():
        return FileResponse(os.path.join(PASTA, nome_arquivo))
    return enviar


for _rota, _arquivo in ARQUIVOS_PUBLICOS.items():
    app.add_api_route(_rota, _rota_arquivo(_arquivo), methods=["GET"], include_in_schema=False)


@app.get("/")
async def barra():
    return RedirectResponse(url="/app")
      # U2VqYSBSaWNrIFJvbGxhZG8h


@app.get("/health")
async def health():
    # Retornar o status do servidor do FastAPI
    return {"message": "Proxy OK!"}


@app.get("/events")
async def eventos(
    limit: int = 10,  # Quantidade Limite de Ocorrencias retornadas
    period: (
        str | None
    ) = None,  # Quantos dias serão consolidados a partir de hoje Ex.: 20 seriam até 20 dias atrás com todas as ocorrencias
    category: str | None = None,  # Tipo de Ocorrencia traga
    status: str | None = None,  # A ocorrencia já foi fechada ou esta em aberto?
    bbox: str | None = Query(
        default=None,
        title="Bounding Box",
        description="Coordenadas no formato: **oeste, sul, leste, norte**. Todas separadas entre sí por vírgulas.",
        example="-46.63, -23.55, -46.60, -23.50",
    ),
):
    params_raw = {
        "limit": limit,
        "days": period,
        "status": status,
        "category": category,
        "bbox": bbox,
    }

    params_filter = {
        chave: valor for chave, valor in params_raw.items() if valor is not None
    }
    # Busca os eventos climaticos na API EONET
    async with httpx.AsyncClient(timeout=httpx.Timeout(5)) as client:
        chamada_api = await client.get(
            r"https://eonet.gsfc.nasa.gov/api/v3/events", params=params_filter
        )

    if chamada_api.is_success:
        return parse_eventos(chamada_api.json())
    else:
        return {"mensagem": "Problemas no retorno da API"}


@app.get("/precipitation_daily")
async def precipitation_daily(
    lat: float = Query(..., description="Latitude do ponto"),
    lon: float = Query(..., description="Longitude do ponto"),
    start: str = Query(..., description="Data inicial no formato AAAAMMDD"),
    end: str = Query(..., description="Data final no formato AAAAMMDD"),
):
    
    cache_existente = ler_cache(lat, lon, start, end)   # ← ADICIONAR
    if cache_existente is not None:                     # ← ADICIONAR
        return cache_existente 
    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }

    async with httpx.AsyncClient(timeout=httpx.Timeout(5)) as client:
        chamada_api = await client.get(
            "https://power.larc.nasa.gov/api/temporal/daily/point", params=params
        )

    if not chamada_api.is_success:
        return {"mensagem": "Problemas no retorno da API"}

    resposta = chamada_api.json()
    dados_diarios = (
        resposta.get("properties", {}).get("parameter", {}).get("PRECTOTCORR", {})
    )

    daily = [
        {"date": data, "precipitation_mm": valor}
        for data, valor in dados_diarios.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]

    resultado = {"lat": lat, "lon": lon, "daily": daily}   # ← NOVA
    salvar_cache(lat, lon, start, end, resultado)          # ← NOVA
    return resultado


@app.get("/precipitation_hourly")
async def precipitation_hourly(
    lat: float = Query(..., description="Latitude do ponto"),
    lon: float = Query(..., description="Longitude do ponto"),
    start: str = Query(..., description="Data inicial no formato AAAAMMDD"),
    end: str = Query(..., description="Data final no formato AAAAMMDD"),
):
    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }

    async with httpx.AsyncClient(timeout=httpx.Timeout(5)) as client:
        chamada_api = await client.get(
            "https://power.larc.nasa.gov/api/temporal/hourly/point", params=params
        )

    if not chamada_api.is_success:
        return {"mensagem": "Problemas no retorno da API"}

    resposta = chamada_api.json()
    dados_horarios = (
        resposta.get("properties", {}).get("parameter", {}).get("PRECTOTCORR", {})
    )

    hourly = [
        {"datetime": data_hora, "precipitation_mm": valor}
        for data_hora, valor in dados_horarios.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]

    return {"lat": lat, "lon": lon, "hourly": hourly}

@app.get("/precipitation_grid")
async def precipitation_grid(
    start: str = Query(..., description="Data inicial no formato AAAAMMDD"),
    end: str = Query(..., description="Data final no formato AAAAMMDD"),
):
    pontos = gerar_grade()
    resultados = []

    for ponto in pontos:
        dados = await precipitation_daily(ponto["lat"], ponto["lon"], start, end)
        resultados.append(dados)

    return {"start": start, "end": end, "pontos": resultados}


# ================================================================
# DATASET DE TREINO (usado pelo train_model.py para retreinar o modelo)
# ================================================================
async def buscar_deslizamentos_eonet(limit: int = 100) -> list[dict] | dict:
    async with httpx.AsyncClient(timeout=httpx.Timeout(20)) as client:
        resposta = await client.get(
            "https://eonet.gsfc.nasa.gov/api/v3/categories/landslides",
            params={"status": "all", "limit": limit},
        )

    if not resposta.is_success:
        return {"mensagem": "Problemas no retorno da API EONET"}

    eventos_processados = []
    for evento in resposta.json().get("events", []):
        geometria = evento.get("geometry", [])
        if not geometria:
            continue

        ultimo_ponto = geometria[-1]
        coordenadas = ultimo_ponto.get("coordinates", [])
        if len(coordenadas) < 2:
            continue

        lon, lat = coordenadas[:2]
        eventos_processados.append(
            {
                "id": evento.get("id"),
                "title": evento.get("title"),
                "date": ultimo_ponto.get("date"),
                "lat": lat,
                "lon": lon,
            }
        )

    return eventos_processados


async def criar_amostra_precipitacao(
    lat: float, lon: float, data_referencia, target: int, event_id: str, title: str
) -> dict | None:
    """Mesma lógica de features do /predict_risk, mas rotulada para treino."""
    features = await criar_features_risco(lat, lon, data_referencia)

    if "mensagem" in features:
        print(f"[amostra descartada] event_id={event_id} motivo={features['mensagem']}")
        return None

    return {
        "event_id": event_id,
        "title": title,
        "date": data_referencia.isoformat(),
        "lat": lat,
        "lon": lon,
        **features,
        "target": target,
    }


@app.get("/landslides")
async def deslizamentos(limit: int = 100):
    """Deslizamentos registrados na NASA EONET (base do treino do modelo)."""
    return await buscar_deslizamentos_eonet(limit)


@app.get("/dataset/training")
async def dataset_training(limit: int = 100):
    """Positivos = data do deslizamento; negativos = 30/60/90/120 dias antes."""
    eventos = await buscar_deslizamentos_eonet(limit)
    if isinstance(eventos, dict):
        return eventos

    dataset = []
    for evento in eventos:
        if not evento["date"]:
            continue

        data_evento = datetime.fromisoformat(evento["date"].replace("Z", "+00:00")).date()

        positivo = await criar_amostra_precipitacao(
            evento["lat"], evento["lon"], data_evento, 1, evento["id"], evento["title"]
        )
        if positivo is not None:
            dataset.append(positivo)

        for deslocamento in (30, 60, 90, 120):
            negativo = await criar_amostra_precipitacao(
                evento["lat"],
                evento["lon"],
                data_evento - timedelta(days=deslocamento),
                0,
                f"NEG_{evento['id']}_{deslocamento}",
                "Sem evento registrado",
            )
            if negativo is not None:
                dataset.append(negativo)

    positivos = sum(1 for item in dataset if item["target"] == 1)
    return {
        "total_samples": len(dataset),
        "positive_samples": positivos,
        "negative_samples": len(dataset) - positivos,
        "dataset": dataset,
    }
