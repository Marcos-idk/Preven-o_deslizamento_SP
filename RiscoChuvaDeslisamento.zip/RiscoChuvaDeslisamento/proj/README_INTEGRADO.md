# Projeto integrado — Chuva + Machine Learning

Este projeto une as duas partes:

1. **Mapa de chuva**: mostra a precipitação por município de São Paulo.
2. **Machine Learning**: usa o modelo `Random Forest` treinado no projeto de deslizamentos.
3. **Integração**: ao selecionar uma cidade, o frontend envia latitude, longitude e data para `/predict_risk`. A API busca os 14 dias anteriores de precipitação na NASA POWER, calcula as mesmas quatro variáveis usadas no treinamento e passa esses valores ao modelo.

## Estrutura principal

- `index.html` — interface.
- `script.js` — mapa, seleção da cidade e chamada do risco.
- `style.css` — estilos.
- `api.py` — FastAPI com chuva + previsão de risco.
- `modelo_deslizamento.joblib` — modelo treinado.
- `precipitacao_grade.json` — dados locais usados pelo mapa.

## O que foi corrigido nesta versão

- A página agora é servida pela própria API (`/app`), o card de risco fica no topo da ficha da cidade e as mensagens de erro dizem o que fazer.
- `api.py` chamava `buscar_precipitacao()` sem defini-la, então `/predict_risk` dava erro. A função foi trazida do projeto de ML e passou a usar o cache em disco do projeto de chuva.
- Se a NASA POWER ainda não tiver os 14 dias completos (os dados têm alguns dias de atraso), a API responde com um aviso em vez de calcular com dados incompletos.
- `train_model.py` e os endpoints `/landslides` e `/dataset/training` foram incluídos, para o modelo poder ser retreinado dentro deste projeto:
  `python train_model.py --api-url http://127.0.0.1:8000 --limit 100`
- Removidos `__pycache__` e o `requiriment.txt` duplicado (com erro de digitação). `requirements.txt` agora inclui `pandas` e `requests`.

## Instalação

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Executar

```bash
uvicorn api:app --reload
```

Depois abra **http://127.0.0.1:8000** no navegador. A própria API entrega a página, os dados de chuva e o cálculo de risco, então não precisa de Live Server.

> Não abra o `index.html` com duplo clique (`file://`): o navegador bloqueia a leitura do `precipitacao_grade.json` e a tabela e o mapa de chuva não carregam.

A documentação da API fica em:

`http://127.0.0.1:8000/docs`

## Fluxo da integração

```text
Usuário escolhe cidade
        ↓
Frontend obtém o centroide da cidade
        ↓
GET /predict_risk?lat=...&lon=...&date=...
        ↓
NASA POWER → últimos 14 dias de chuva
        ↓
1d + 3d + 7d + 14d
        ↓
Random Forest
        ↓
probabilidade estimada + nível
        ↓
Tela da cidade
```

## Importante sobre o modelo

A estimativa é experimental. O modelo usa somente precipitação como entrada; não considera declividade, tipo de solo, drenagem, ocupação urbana ou outros fatores que influenciam deslizamentos. Portanto, o resultado não deve ser tratado como alerta oficial ou previsão determinística.

O treinamento original também usa eventos de deslizamento da NASA EONET e amostras negativas construídas a partir de datas anteriores aos eventos. Para uma versão mais robusta, o próximo passo é melhorar o dataset e validar o modelo com dados separados por tempo e região.

## Atenção: chave da API Groq

O `script.js` tem uma chave da Groq escrita no código (`GROQ_API_KEY`). Como o arquivo vai para o navegador, qualquer pessoa consegue copiá-la. Gere uma chave nova no painel da Groq, revogue a atual e, de preferência, faça a chamada à Groq pelo backend (`api.py`) em vez de pelo `script.js`. Não suba esta chave para o GitHub.
