import json
from pathlib import Path
from typing import Optional

# Pasta onde os arquivos de cache serão salvos.
CACHE_DIR = Path(__file__).parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)


def _nome_arquivo(lat: float, lon: float, start: str, end: str) -> Path:
    def sanitizar(valor: float) -> str:
        return f"{valor:.4f}".replace("-", "n").replace(".", "p")

    nome = f"{sanitizar(lat)}_{sanitizar(lon)}_{start}_{end}.json"
    return CACHE_DIR / nome


def ler_cache(lat: float, lon: float, start: str, end: str) -> Optional[dict]:

    caminho = _nome_arquivo(lat, lon, start, end)
    if not caminho.exists():
        return None

    try:
        with open(caminho, "r", encoding="utf-8") as arquivo:
            return json.load(arquivo)

    except (json.JSONDecodeError, OSError):
        return None


def salvar_cache(lat: float, lon: float, start: str, end: str, dados: dict) -> None:

    caminho = _nome_arquivo(lat, lon, start, end)

    with open(caminho, "w", encoding="utf-8") as arquivo:
        json.dump(dados, arquivo, ensure_ascii=False, indent=2)