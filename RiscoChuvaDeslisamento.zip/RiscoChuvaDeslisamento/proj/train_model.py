import argparse
import sys

import joblib
import numpy as np
import pandas as pd
import requests
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

FEATURES = [
    "precipitation_1d",
    "precipitation_3d",
    "precipitation_7d",
    "precipitation_14d",
]
TARGET = "target"


def buscar_dataset(api_url: str, limit: int) -> pd.DataFrame:
    """Busca o dataset de treino direto do endpoint /dataset/training."""
    url = f"{api_url.rstrip('/')}/dataset/training"
    print(f"Buscando dataset em {url} (limit={limit})...")

    resposta = requests.get(url, params={"limit": limit}, timeout=300)
    resposta.raise_for_status()
    payload = resposta.json()

    if "dataset" not in payload:
        print("Resposta inesperada da API:", payload)
        sys.exit(1)

    df = pd.DataFrame(payload["dataset"])

    print(
        f"Total de amostras: {payload.get('total_samples', len(df))} "
        f"(positivas={payload.get('positive_samples')}, "
        f"negativas={payload.get('negative_samples')})"
    )

    return df


def preparar_dados(df: pd.DataFrame) -> pd.DataFrame:
    """Remove linhas incompletas e garante os tipos corretos."""
    antes = len(df)
    df = df.dropna(subset=FEATURES + [TARGET]).copy()
    depois = len(df)

    if antes != depois:
        print(f"Descartadas {antes - depois} amostras com dados faltantes.")

    df[TARGET] = df[TARGET].astype(int)
    return df


def avaliar_modelo(nome: str, modelo, X_test, y_test) -> None:
    y_pred = modelo.predict(X_test)
    y_proba = modelo.predict_proba(X_test)[:, 1]

    print(f"\n=== {nome} ===")
    print(classification_report(y_test, y_pred, digits=3))
    print("Matriz de confusão:")
    print(confusion_matrix(y_test, y_pred))
    print(f"ROC AUC: {roc_auc_score(y_test, y_proba):.3f}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api-url", default="http://127.0.0.1:8000")
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--test-size", type=float, default=0.25)
    parser.add_argument("--random-state", type=int, default=42)
    parser.add_argument(
        "--output", default="modelo_deslizamento.joblib",
        help="Arquivo onde o modelo treinado (+ scaler) será salvo",
    )
    args = parser.parse_args()

    df = buscar_dataset(args.api_url, args.limit)
    df = preparar_dados(df)

    if df[TARGET].nunique() < 2:
        print("Dataset não tem as duas classes (0 e 1). Aumente o --limit.")
        sys.exit(1)

    X = df[FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=args.test_size,
        random_state=args.random_state,
        stratify=y,
    )

    # Padronização (útil para a regressão logística; não atrapalha a random forest)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    modelos = {
        "Regressão Logística": LogisticRegression(
            class_weight="balanced", max_iter=1000
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            class_weight="balanced",
            random_state=args.random_state,
        ),
    }

    resultados = {}

    for nome, modelo in modelos.items():
        if nome == "Regressão Logística":
            modelo.fit(X_train_scaled, y_train)
            avaliar_modelo(nome, modelo, X_test_scaled, y_test)
        else:
            modelo.fit(X_train, y_train)
            avaliar_modelo(nome, modelo, X_test, y_test)

        resultados[nome] = modelo

    # Importância das features (Random Forest é mais fácil de interpretar aqui)
    rf = resultados["Random Forest"]
    importancias = pd.Series(rf.feature_importances_, index=FEATURES)
    importancias = importancias.sort_values(ascending=False)

    print("\n=== Importância das features (Random Forest) ===")
    print(importancias.to_string())

    # Salva o modelo Random Forest (não precisa do scaler) + scaler para a logística
    joblib.dump(
        {
            "random_forest": rf,
            "logistic_regression": resultados["Regressão Logística"],
            "scaler": scaler,
            "features": FEATURES,
        },
        args.output,
    )
    print(f"\nModelo salvo em: {args.output}")


if __name__ == "__main__":
    main()