import asyncio
import json
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
import httpx

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

PRECTOTCORR_FILL_VALUE = -999


def parse_eventos(resposta_eonet: dict) -> list[dict]:
    eventos_parseados = []
    for evento in resposta_eonet.get("events", []):
        categorias = evento.get("categories", [])
        categoria = categorias[0]["title"] if categorias else None
        geometria = evento.get("geometry", [])
        ultimo_ponto = geometria[-1] if geometria else None

        if ultimo_ponto:
            lon, lat = ultimo_ponto["coordinates"]
            data = ultimo_ponto.get("date")
        else:
            lon, lat, data = None, None, None

        eventos_parseados.append(
            {
                "id": evento.get("id"),
                "title": evento.get("title"),
                "category": categoria,
                "date": data,
                "lat": lat,
                "lon": lon,
                "closed": evento.get("closed") is not None,
            }
        )
    return eventos_parseados


@app.get("/")
async def barra():
    return RedirectResponse(url="/docs")


@app.get("/health")
async def health():
    return {"message": "Proxy OK!"}


@app.get("/events")
async def eventos(
    limit: int = 10,
    period: str | None = None,
    category: str | None = None,
    status: str | None = None,
    bbox: str | None = Query(default=None),
):
    params_raw = {
        "limit": limit,
        "days": period,
        "status": status,
        "category": category,
        "bbox": bbox,
    }
    params_filter = {k: v for k, v in params_raw.items() if v is not None}
    async with httpx.AsyncClient(timeout=httpx.Timeout(10)) as client:
        chamada_api = await client.get(
            r"https://eonet.gsfc.nasa.gov/api/v3/events", params=params_filter
        )
    if chamada_api.is_success:
        return parse_eventos(chamada_api.json())
    else:
        return {"mensagem": "Problemas no retorno da API"}


# =====================================================================
# CONSULTAR PONTO - NASA POWER API
# =====================================================================
async def consultar_ponto_grade(
    client: httpx.AsyncClient, 
    lat: float, 
    lon: float, 
    start: str, 
    end: str,
    sem: asyncio.Semaphore # Semáforo adicionado para evitar bloqueio
):
    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }
    
    # O bloco 'async with sem' garante que respeitaremos o limite máximo de requisições simultâneas
    async with sem:
        try:
            # Uma pequena pausa de segurança (0.1s) entre os disparos evita o gatilho de DDoS da NASA
            await asyncio.sleep(0.1)
            
            chamada_api = await client.get(
                "https://nasa.gov",
                params=params,
                timeout=20.0,
            )
            
            if chamada_api.status_code == 429:
                print(f"⚠️ NASA Bloqueou (429 - Too Many Requests) no ponto {lat}, {lon}. Reduzindo ritmo...")
                return None
                
            if not chamada_api.is_success:
                print(f"❌ NASA retornou erro {chamada_api.status_code} para o ponto {lat}, {lon}")
                return None

            resposta = chamada_api.json()
            dados_diarios = (
                resposta.get("properties", {})
                .get("parameter", {})
                .get("PRECTOTCORR", {})
            )

            valores = [
                v for v in dados_diarios.values() if v != PRECTOTCORR_FILL_VALUE
            ]
            if not valores:
                return None

            media = sum(valores) / len(valores)
            return {"lat": lat, "lon": lon, "precipitation": round(media, 2)}
        except Exception as e:
            print(f"💥 Falha de conexão no ponto {lat}, {lon}: {e}")
            return None

# =====================================================================
# ROTA DA GRADE - ESTADO DE SÃO PAULO
# =====================================================================
@app.get("/precipitation_grid")
async def precipitation_grid(
    start: str = Query(..., description="Data inicial no formato AAAAMMDD"),
    end: str = Query(..., description="Data final no formato AAAAMMDD"),
    passo: float = Query(
        1.0, description="Distância entre os pontos (Ex: 1.0 ou 0.2)"
    ),
):
    # Retângulo envolvente oficial do Estado de São Paulo
    LAT_MIN, LAT_MAX = -25.30, -19.77
    LON_MIN, LON_MAX = -53.11, -44.16

    # Criamos listas fixas para mapear as coordenadas perfeitamente
    latitudes = []
    curr_lat = LAT_MIN
    while curr_lat <= LAT_MAX:
        latitudes.append(round(curr_lat, 2))
        curr_lat += passo

    longitudes = []
    curr_lon = LON_MIN
    while curr_lon <= LON_MAX:
        longitudes.append(round(curr_lon, 2))
        curr_lon += passo

    # Limita o paralelismo a NO MÁXIMO 5 requisições simultâneas (evita erros 429 e quedas)
    sem = asyncio.Semaphore(5)
    tarefas = []

    # Configuração de conexões persistentes mais conservadora para evitar rejeição do servidor remoto
    limiter = httpx.Limits(max_keepalive_connections=5, max_connections=10)

    async with httpx.AsyncClient(limits=limiter, timeout=httpx.Timeout(90.0)) as client:
        for lat in latitudes:
            for lon in longitudes:
                tarefas.append(
                    consultar_ponto_grade(client, lat, lon, start, end, sem)
                )

        print(f"🚀 Iniciando consulta controlada de {len(tarefas)} pontos por todo o mapa de SP...")
        resultados_brutos = await asyncio.gather(*tarefas)

    resultados_validos = [r for r in resultados_brutos if r is not None]

    resposta_final = {
        "total_pontos": len(resultados_validos),
        "passo_utilizado": passo,
        "grid": resultados_validos,
    }

    nome_arquivo = f"dados_chuva_{start}_a_{end}_passo_{passo}.json"
    with open(nome_arquivo, "w", encoding="utf-8") as arquivo:
        json.dump(resposta_final, arquivo, indent=4, ensure_ascii=False)

    print(f"✨ Concluído! Arquivo salvo com {len(resultados_validos)} pontos válidos.")
    return resposta_final


# =====================================================================
# ROTAS INDIVIDUAIS DIÁRIAS (CORRIGIDA)
# =====================================================================
@app.get("/precipitation_daily")
async def precipitation_daily(
    lat: float = Query(...),
    lon: float = Query(...),
    start: str = Query(...),
    end: str = Query(...),
):
    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }
    async with httpx.AsyncClient(timeout=httpx.Timeout(10)) as client:
        chamada_api = await client.get(
            "https://power.larc.nasa.gov/api/temporal/daily/point",
            params=params,
        )
    
    # CORRIGIDO: de 'llamada_api' para 'chamada_api' para evitar crash de NameError
    if not chamada_api.is_success:
        return {"mensagem": "Problemas no retorno da API"}
        
    resposta = chamada_api.json()
    dados_diarios = (
        resposta.get("properties", {}).get("parameter", {}).get("PRECTOTCORR", {})
    )
    daily = [
        {"date": data, "precipitation_mm": valor}
        for data, valor in dados_diarios.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]
    return {"lat": lat, "lon": lon, "daily": daily}


@app.get("/precipitation_hourly")
async def precipitation_hourly(
    lat: float = Query(...),
    lon: float = Query(...),
    start: str = Query(...),
    end: str = Query(...),
):
    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }
    async with httpx.AsyncClient(timeout=httpx.Timeout(10)) as client:
        chamada_api = await client.get(
            "https://power.larc.nasa.gov/api/temporal/hourly/point",
            params=params,
        )
    if not chamada_api.is_success:
        return {"mensagem": "Problemas no retorno da API"}
    resposta = chamada_api.json()
    dados_horarios = (
        resposta.get("properties", {}).get("parameter", {}).get("PRECTOTCORR", {})
    )
    hourly = [
        {"datetime": data_hora, "precipitation_mm": valor}
        for data_hora, valor in dados_horarios.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]
    return {"lat": lat, "lon": lon, "hourly": hourly}
