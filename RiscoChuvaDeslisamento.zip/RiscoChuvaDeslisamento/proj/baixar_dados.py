import asyncio
import json

import httpx

from cache import ler_cache, salvar_cache
from grade import gerar_grade

# Formato das datas: AAAAMMDD 
START = "20250101"
END = "20251231"

ARQUIVO_SAIDA = "precipitacao_grade.json"

PRECTOTCORR_FILL_VALUE = -999  # valor que a NASA usa quando não tem dado


async def consultar_ponto(
    client: httpx.AsyncClient,
    lat: float,
    lon: float,
    start: str,
    end: str,
) -> dict:

    # --------------------------------------------------
    # Verifica o cache em disco antes de ir na NASA
    # --------------------------------------------------

    cache_existente = ler_cache(lat, lon, start, end)

    if cache_existente is not None:
        print(f"[cache] lat={lat} lon={lon}")
        return cache_existente

    print(f"[NASA]  lat={lat} lon={lon}")

    params = {
        "parameters": "PRECTOTCORR",
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": start,
        "end": end,
        "format": "JSON",
    }

    resposta = await client.get(
        "https://power.larc.nasa.gov/api/temporal/daily/point", params=params
    )

    if not resposta.is_success:
        print(f"  -> erro {resposta.status_code} nesse ponto, pulando")
        return {"lat": lat, "lon": lon, "daily": []}

    dados = resposta.json()

    dados_diarios = (
        dados.get("properties", {}).get("parameter", {}).get("PRECTOTCORR", {})
    )

    daily = [
        {"date": data, "precipitation_mm": valor}
        for data, valor in dados_diarios.items()
        if valor != PRECTOTCORR_FILL_VALUE
    ]

    resultado = {"lat": lat, "lon": lon, "daily": daily}

    salvar_cache(lat, lon, start, end, resultado)

    return resultado


async def main() -> None:

    pontos = gerar_grade()

    print(f"Consultando {len(pontos)} pontos (start={START}, end={END})...\n")

    resultados = []

    async with httpx.AsyncClient(timeout=httpx.Timeout(15)) as client:

        for ponto in pontos:

            resultado = await consultar_ponto(
                client, ponto["lat"], ponto["lon"], START, END
            )

            resultados.append(resultado)

    saida = {"start": START, "end": END, "pontos": resultados}

    with open(ARQUIVO_SAIDA, "w", encoding="utf-8") as arquivo:
        json.dump(saida, arquivo, ensure_ascii=False, indent=2)

    print(f"\nPronto! {len(resultados)} pontos salvos em '{ARQUIVO_SAIDA}'.")


if __name__ == "__main__":
    asyncio.run(main())