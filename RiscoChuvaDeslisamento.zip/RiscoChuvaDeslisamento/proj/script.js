// Se a página é servida pela própria API (porta 8000), usa a mesma origem.
const API_URL = window.location.port === "8000"
    ? window.location.origin
    : "http://127.0.0.1:8000";

const ABERTO_POR_ARQUIVO = window.location.protocol === "file:";
const AJUDA_SERVIDOR =
    "Rode na pasta do projeto: uvicorn api:app --reload  e abra http://127.0.0.1:8000";

const GROQ_API_KEY = "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";
const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODELO = "openai/gpt-oss-120b";
let controladorIA = null;

// ---------- coordenadas do raster ----------
const LAT_MIN = -25;
const LAT_MAX = -19;
const LON_MIN = -54;
const LON_MAX = -44;

// ---------- interpolação (IDW) ----------
const PASSO_INTERPOLACAO = 0.10;
const NUM_VIZINHOS = 12;
const POTENCIA_IDW = 2;

// Escala: areia (pouca chuva) -> azul claro -> azul profundo (muita chuva)
const CORES_GRADIENTE = [
    { parada: 0.0, cor: [234, 223, 200] },  // #EADFC8
    { parada: 0.5, cor: [142, 195, 218] },  // #8EC3DA
    { parada: 1.0, cor: [14, 74, 107] }     // #0E4A6B
];


const CAMPOS_DATA = ["date", "data", "time", "day", "dia"];
const DATA_INICIAL_JSON = "2025-01-01";
let usouDataFallback = false;

const MESES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
const MESES_LONGOS = [
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
];

const map = L.map("map", {
    scrollWheelZoom: false,
    dragging: !L.Browser.mobile
});

map.fitBounds([[LAT_MIN, LON_MIN], [LAT_MAX, LON_MAX]]);

// Mapa-base CARTO (dados do OpenStreetMap). Os tiles oficiais do OSM devolvem
// 403 "Access blocked" quando a página é aberta via file:// (sem Referer).
L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
    attribution: "&copy; OpenStreetMap contributors &copy; CARTO",
    subdomains: "abcd",
    maxZoom: 19
}).addTo(map);


map.createPane("rasterPane");
map.getPane("rasterPane").style.zIndex = 250;


let rasterLayer = null;
let limiteSP = null;
let limiteMunicipios = null;
let promessaLimiteSP = null;

let dadosGrade = null;            
let municipios = [];             
let municipioSelecionado = null;
let destaqueMapa = null;          // contorno do município selecionado

// Guarda o último resumo calculado (entrada do LLM).
let ultimoResumoCidade = null;

const ESTILO_MUNICIPIO = { color: "#7a8894", weight: 0.6, fillOpacity: 0 };

// formatação
function formatarNumero(valor, casas = 1) {
    return valor.toLocaleString("pt-BR", {
        minimumFractionDigits: casas,
        maximumFractionDigits: casas
    });
}

function formatarDataBR(dataIso) {
    return dataIso.split("-").reverse().join("/");
}

function semAcento(texto) {
    return texto
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
}

function lerPeriodo() {
    return {
        inicio: document.getElementById("dataInicio").value,
        fim: document.getElementById("dataFim").value
    };
}

function distanciaKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const rad = Math.PI / 180;

    const dLat = (lat2 - lat1) * rad;
    const dLon = (lon2 - lon1) * rad;

    const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}


// GEOMETRIA (ponto em polígono, centroide)
function poligonosDaGeometria(geometry) {
    if (!geometry) return [];
    if (geometry.type === "Polygon") return [geometry.coordinates];
    if (geometry.type === "MultiPolygon") return geometry.coordinates;
    return [];
}

function pontoDentroDoAnel(ponto, anel) {
    const [x, y] = ponto;
    let dentro = false;

    for (let i = 0, j = anel.length - 1; i < anel.length; j = i++) {
        const xi = anel[i][0];
        const yi = anel[i][1];
        const xj = anel[j][0];
        const yj = anel[j][1];

        const intersecta =
            (yi > y) !== (yj > y) &&
            x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;

        if (intersecta) {
            dentro = !dentro;
        }
    }

    return dentro;
}

function pontoDentroDaGeometria(lat, lon, geometry) {
    const ponto = [lon, lat];

    for (const aneis of poligonosDaGeometria(geometry)) {
        if (!aneis || aneis.length === 0) continue;
        if (!pontoDentroDoAnel(ponto, aneis[0])) continue;

        const dentroDeBuraco = aneis.slice(1).some(buraco => pontoDentroDoAnel(ponto, buraco));
        if (!dentroDeBuraco) return true;
    }

    return false;
}

// verifica se o ponto está dentro de SP
function pontoDentroDeSP(lat, lon) {
    if (!limiteSP) return false;

    return (limiteSP.features || []).some(feature =>
        pontoDentroDaGeometria(lat, lon, feature.geometry)
    );
}

// range de coordenadas (caixa) do município
function calcularBbox(geometry) {
    let latMin = Infinity;
    let latMax = -Infinity;
    let lonMin = Infinity;
    let lonMax = -Infinity;

    for (const aneis of poligonosDaGeometria(geometry)) {
        for (const [lon, lat] of aneis[0]) {
            if (lat < latMin) latMin = lat;
            if (lat > latMax) latMax = lat;
            if (lon < lonMin) lonMin = lon;
            if (lon > lonMax) lonMax = lon;
        }
    }

    return { latMin, latMax, lonMin, lonMax };
}

// centroide (fórmula da área)
function centroideDoAnel(anel) {
    let area = 0;
    let cx = 0;
    let cy = 0;

    for (let i = 0, j = anel.length - 1; i < anel.length; j = i++) {
        const [xi, yi] = anel[i];
        const [xj, yj] = anel[j];
        const f = xj * yi - xi * yj;

        area += f;
        cx += (xj + xi) * f;
        cy += (yj + yi) * f;
    }

    area /= 2;

    if (Math.abs(area) < 1e-12) {
        return { lon: anel[0][0], lat: anel[0][1], area: 0 };
    }

    return { lon: cx / (6 * area), lat: cy / (6 * area), area: Math.abs(area) };
}

// centroide do maior polígono do município
function calcularCentroide(geometry) {
    let melhor = null;

    for (const aneis of poligonosDaGeometria(geometry)) {
        const c = centroideDoAnel(aneis[0]);
        if (!melhor || c.area > melhor.area) {
            melhor = c;
        }
    }

    return melhor;
}

// LIMITES (IBGE)
async function carregarLimiteSP() {
    const url =
        "https://servicodados.ibge.gov.br/api/v3/malhas/estados/SP?formato=application/vnd.geo+json&qualidade=minima";

    try {
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`Erro ao carregar malha do IBGE: ${response.status}`);
        }

        limiteSP = await response.json();

        L.geoJSON(limiteSP, {
            style: { color: "#16232e", weight: 1.6, fillOpacity: 0 },
            interactive: false
        }).addTo(map);

    } catch (erro) {
        console.error("Erro ao carregar limite de SP:", erro);
        promessaLimiteSP = null; 
    }
}

// Garante que o limite seja carregado uma única vez (evita desenhar duas vezes).
function garantirLimiteSP() {
    if (!promessaLimiteSP) {
        promessaLimiteSP = carregarLimiteSP();
    }
    return promessaLimiteSP;
}

async function carregarLimitesMunicipios() {
    const urlMalha =
        "https://servicodados.ibge.gov.br/api/v3/malhas/estados/SP?intrarregiao=municipio&formato=application/vnd.geo+json&qualidade=minima";

    const urlNomes =
        "https://servicodados.ibge.gov.br/api/v1/localidades/estados/35/municipios";

    const campo = document.getElementById("municipio");

    try {
        const [respMalha, respNomes] = await Promise.all([fetch(urlMalha), fetch(urlNomes)]);

        if (!respMalha.ok) {
            throw new Error(`Erro ao carregar malha de municípios: ${respMalha.status}`);
        }
        if (!respNomes.ok) {
            throw new Error(`Erro ao carregar nomes dos municípios: ${respNomes.status}`);
        }

        limiteMunicipios = await respMalha.json();
        const listaNomes = await respNomes.json();
        const nomes = new Map(listaNomes.map(m => [String(m.id), m.nome]));

        L.geoJSON(limiteMunicipios, {
            style: ESTILO_MUNICIPIO,
            onEachFeature: (feature, layer) => {
                const codigo = String(feature.properties.codarea);
                const nome = nomes.get(codigo) ?? codigo;

                municipios.push({
                    codigo,
                    nome,
                    chave: semAcento(nome),
                    geometry: feature.geometry,
                    bbox: calcularBbox(feature.geometry),
                    centroide: calcularCentroide(feature.geometry),
                    layer
                });

                layer.bindTooltip(nome, { sticky: true });
                layer.on("click", () => selecionarMunicipio(codigo));
            }
        }).addTo(map);

        municipios.sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
        preencherListaMunicipios();

        campo.disabled = false;
        campo.placeholder = "Digite o nome da sua cidade";

    } catch (erro) {
        console.error("Erro ao carregar limites dos municípios:", erro);
        campo.placeholder = "Não foi possível carregar a lista de cidades";
    }
}

function preencherListaMunicipios() {
    const lista = document.getElementById("listaMunicipios");
    lista.innerHTML = "";

    for (const mun of municipios) {
        const opcao = document.createElement("option");
        opcao.value = mun.nome;
        lista.appendChild(opcao);
    }
}

// DADOS DA GRADE (precipitacao_grade.json)

async function carregarDadosGrade() {
    if (dadosGrade) return dadosGrade;

    const resposta = await fetch("precipitacao_grade.json");

    if (!resposta.ok) {
        throw new Error(`HTTP ${resposta.status}`);
    }

    dadosGrade = await resposta.json();
    return dadosGrade;
}

// aceita "2025-01-31", "2025-01-31T00:00" e "20250131"
function normalizarData(valor) {
    const texto = String(valor ?? "");

    if (/^\d{8}$/.test(texto)) {
        return `${texto.slice(0, 4)}-${texto.slice(4, 6)}-${texto.slice(6, 8)}`;
    }

    const iso = texto.slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(iso) ? iso : null;
}

function somarDias(dataIso, dias) {
    const [ano, mes, dia] = dataIso.split("-").map(Number);
    return new Date(Date.UTC(ano, mes - 1, dia + dias)).toISOString().slice(0, 10);
}

function dataDoDia(dia, indice) {
    for (const campo of CAMPOS_DATA) {
        const data = normalizarData(dia[campo]);
        if (data) return data;
    }

    usouDataFallback = true;
    return somarDias(DATA_INICIAL_JSON, indice);
}

function obterDias(item, inicio, fim) {
    if (!item || !Array.isArray(item.daily)) return [];

    const dias = [];

    item.daily.forEach((dia, indice) => {
        const mm = dia.precipitation_mm;

        if (mm === null || mm === undefined || Number.isNaN(mm)) return;

        const data = dataDoDia(dia, indice);

        if (inicio && data < inicio) return;
        if (fim && data > fim) return;

        dias.push({ data, mm });
    });

    return dias;
}

// média de precipitação (mm/dia) no período analisado
function calcularMediaDiaria(item, inicio, fim) {
    const dias = obterDias(item, inicio, fim);

    if (dias.length === 0) return null;

    const acumulado = dias.reduce((soma, dia) => soma + dia.mm, 0);
    return acumulado / dias.length;
}

function resumoMensalDoPonto(item, inicio, fim) {
    const meses = new Map();

    for (const { data, mm } of obterDias(item, inicio, fim)) {
        const mes = data.slice(0, 7);
        const atual = meses.get(mes) ?? { soma: 0, dias: 0 };

        atual.soma += mm;
        atual.dias += 1;
        meses.set(mes, atual);
    }

    return meses;
}

// média entre os pontos
function tabelaMensal(pontos, inicio, fim) {
    const acumulado = new Map();

    for (const ponto of pontos) {
        for (const [mes, { soma, dias }] of resumoMensalDoPonto(ponto, inicio, fim)) {
            const atual = acumulado.get(mes) ?? { somaTotais: 0, n: 0, dias: 0 };

            atual.somaTotais += soma;
            atual.n += 1;
            atual.dias = Math.max(atual.dias, dias);
            acumulado.set(mes, atual);
        }
    }

    return [...acumulado.entries()]
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([mes, a]) => {
            const total = a.somaTotais / a.n;
            return { mes, total, mediaDiaria: total / a.dias, dias: a.dias };
        });
}

// Escolhe os pontos da grade que representam o município:
// 1) pontos dentro do município (caixa de coordenadas);
// 2) se não houver nenhum, o ponto mais próximo do centro do município.
function escolherPontos(mun) {
    const candidatos = dadosGrade.pontos.filter(
        p => Array.isArray(p.daily) && p.daily.length > 0
    );

    const { latMin, latMax, lonMin, lonMax } = mun.bbox;

    const dentro = candidatos.filter(p =>
        p.lat >= latMin && p.lat <= latMax &&
        p.lon >= lonMin && p.lon <= lonMax &&
        pontoDentroDaGeometria(p.lat, p.lon, mun.geometry)
    );

    if (dentro.length > 0) {
        return { metodo: "dentro", pontos: dentro };
    }

    let maisProximo = null;
    let menor = Infinity;

    for (const p of candidatos) {
        const d = distanciaKm(mun.centroide.lat, mun.centroide.lon, p.lat, p.lon);
        if (d < menor) {
            menor = d;
            maisProximo = p;
        }
    }

    return {
        metodo: "proximo",
        pontos: maisProximo ? [maisProximo] : [],
        ponto: maisProximo,
        distanciaKm: menor
    };
}


// INTERPOLAÇÃO, sobreposicao
function interpolarIDW(lat, lon, pontos) {
    if (!pontos || pontos.length === 0) {
        return null;
    }

    const distancias = pontos.map(ponto => ({
        ponto: ponto,
        distancia: distanciaKm(lat, lon, ponto.lat, ponto.lon)
    }));

    distancias.sort((a, b) => a.distancia - b.distancia);

    const vizinhos = distancias.slice(0, NUM_VIZINHOS);

    if (vizinhos[0] && vizinhos[0].distancia < 0.001) {
        return vizinhos[0].ponto.precipitation;
    }

    let numerador = 0;
    let denominador = 0;

    for (const vizinho of vizinhos) {
        const peso = 1 / Math.pow(vizinho.distancia, POTENCIA_IDW);

        numerador += vizinho.ponto.precipitation * peso;
        denominador += peso;
    }

    if (denominador === 0) {
        return null;
    }

    return numerador / denominador;
}

function gerarMatrizInterpolada(pontos) {
    const nLat = Math.round((LAT_MAX - LAT_MIN) / PASSO_INTERPOLACAO) + 1;
    const nLon = Math.round((LON_MAX - LON_MIN) / PASSO_INTERPOLACAO) + 1;

    const matriz = [];

    for (let i = 0; i < nLat; i++) {
        const lat = Number((LAT_MIN + i * PASSO_INTERPOLACAO).toFixed(4));
        const linha = [];

        for (let j = 0; j < nLon; j++) {
            const lon = Number((LON_MIN + j * PASSO_INTERPOLACAO).toFixed(4));

            if (!pontoDentroDeSP(lat, lon)) {
                linha.push(null);
                continue;
            }

            linha.push(interpolarIDW(lat, lon, pontos));
        }

        matriz.push(linha);
    }

    return { matriz, nLat, nLon };
}


function valorParaCorRGBA(valor, min, max) {
    if (valor === null || valor === undefined || Number.isNaN(valor)) {
        return [0, 0, 0, 0];
    }

    if (max - min < 0.0001) {
        const meio = CORES_GRADIENTE[1].cor;
        return [meio[0], meio[1], meio[2], 230];
    }

    let fracao = (valor - min) / (max - min);
    fracao = Math.max(0, Math.min(1, fracao));

    for (let i = 0; i < CORES_GRADIENTE.length - 1; i++) {
        const atual = CORES_GRADIENTE[i];
        const proxima = CORES_GRADIENTE[i + 1];

        if (fracao >= atual.parada && fracao <= proxima.parada) {
            const t = (fracao - atual.parada) / (proxima.parada - atual.parada);

            const r = Math.round(atual.cor[0] + (proxima.cor[0] - atual.cor[0]) * t);
            const g = Math.round(atual.cor[1] + (proxima.cor[1] - atual.cor[1]) * t);
            const b = Math.round(atual.cor[2] + (proxima.cor[2] - atual.cor[2]) * t);

            return [r, g, b, 230];
        }
    }

    const ultima = CORES_GRADIENTE[CORES_GRADIENTE.length - 1].cor;
    return [ultima[0], ultima[1], ultima[2], 230];
}

function renderizarRaster(matriz, nLat, nLon) {
    let min = Infinity;
    let max = -Infinity;

    for (const linha of matriz) {
        for (const valor of linha) {
            if (valor === null || Number.isNaN(valor)) continue;

            if (valor < min) min = valor;
            if (valor > max) max = valor;
        }
    }

    if (min === Infinity || max === -Infinity) {
        min = 0;
        max = 1;
    }

    const canvas = document.createElement("canvas");
    canvas.width = nLon;
    canvas.height = nLat;

    const ctx = canvas.getContext("2d");
    const imageData = ctx.createImageData(nLon, nLat);

    for (let i = 0; i < nLat; i++) {
        // i = 0 é o sul do estado; a imagem começa no topo (norte).
        const linhaImagem = nLat - 1 - i;

        for (let j = 0; j < nLon; j++) {
            const valor = matriz[i][j];
            const [r, g, b, a] = valorParaCorRGBA(valor, min, max);

            const indice = (linhaImagem * nLon + j) * 4;

            imageData.data[indice] = r;
            imageData.data[indice + 1] = g;
            imageData.data[indice + 2] = b;
            imageData.data[indice + 3] = a;
        }
    }

    ctx.putImageData(imageData, 0, 0);

    const dataUrl = canvas.toDataURL();
    const bounds = [[LAT_MIN, LON_MIN], [LAT_MAX, LON_MAX]];

    if (rasterLayer) {
        map.removeLayer(rasterLayer);
    }

    rasterLayer = L.imageOverlay(dataUrl, bounds, {
        opacity: 0.85,
        interactive: false,
        pane: "rasterPane"
    }).addTo(map);

    return { min, max };
}

// A barra da legenda é montada a partir da mesma escala usada no mapa.
function atualizarLegenda(min, max) {
    const paradas = CORES_GRADIENTE
        .map(c => `rgb(${c.cor.join(",")}) ${c.parada * 100}%`)
        .join(", ");

    document.getElementById("legendaBarra").style.background =
        `linear-gradient(to right, ${paradas})`;

    document.getElementById("legendaMin").textContent = `${formatarNumero(min, 1)} mm/dia`;
    document.getElementById("legendaMax").textContent = `${formatarNumero(max, 1)} mm/dia`;
    document.getElementById("legenda").hidden = false;
}

// FICHA DO MUNICÍPIO
function mostrarFicha() {
    document.getElementById("fichaVazia").hidden = true;
    document.getElementById("fichaCidade").hidden = false;
}

function limparSelecaoMunicipio() {
    if (destaqueMapa) {
        map.removeLayer(destaqueMapa);
        destaqueMapa = null;
    }

    municipioSelecionado = null;
    reiniciarAnaliseIA();

    document.getElementById("municipio").value = "";
    document.getElementById("fichaCidade").hidden = true;
    document.getElementById("fichaVazia").hidden = false;
}

function destacarMunicipio(mun) {
    if (destaqueMapa) {
        map.removeLayer(destaqueMapa);
    }

    municipioSelecionado = mun;

    destaqueMapa = L.layerGroup([
        L.geoJSON(mun.geometry, { style: { color: "#ffffff", weight: 6, fill: false }, interactive: false }),
        L.geoJSON(mun.geometry, { style: { color: "#16232e", weight: 2.5, fill: false }, interactive: false })
    ]).addTo(map);
}

function limparTabelaMensal() {
    document.querySelector("#tabelaMensal tbody").innerHTML = "";
    document.querySelector("#tabelaMensal tfoot").innerHTML = "";
    document.getElementById("grafico").innerHTML = "";
    document.getElementById("graficoLegenda").innerHTML = "";
}

function nomeMes(mes) {
    const [ano, numero] = mes.split("-");
    return `${MESES[Number(numero) - 1]}/${ano}`;
}

function nomeMesLongo(mes, comAno) {
    const [ano, numero] = mes.split("-");
    const nome = MESES_LONGOS[Number(numero) - 1];
    return comAno ? `${nome} de ${ano}` : nome;
}

function periodoTemVariosAnos(tabela) {
    return new Set(tabela.map(l => l.mes.slice(0, 4))).size > 1;
}

function indicesExtremos(tabela) {
    let iMax = 0;
    let iMin = 0;

    tabela.forEach((linha, i) => {
        if (linha.total > tabela[iMax].total) iMax = i;
        if (linha.total < tabela[iMin].total) iMin = i;
    });

    return { iMax, iMin };
}

function renderizarTabelaMensal(tabela) {
    const corpo = document.querySelector("#tabelaMensal tbody");
    const rodape = document.querySelector("#tabelaMensal tfoot");

    if (tabela.length === 0) {
        corpo.innerHTML = `<tr><td class="vazio" colspan="4">Sem dados no período selecionado.</td></tr>`;
        rodape.innerHTML = "";
        return null;
    }

    corpo.innerHTML = tabela.map(linha => `
        <tr>
            <td>${nomeMes(linha.mes)}</td>
            <td>${formatarNumero(linha.total, 1)}</td>
            <td>${formatarNumero(linha.mediaDiaria, 2)}</td>
            <td>${linha.dias}</td>
        </tr>
    `).join("");

    const totalPeriodo = tabela.reduce((soma, l) => soma + l.total, 0);
    const diasPeriodo = tabela.reduce((soma, l) => soma + l.dias, 0);
    const mediaPeriodo = totalPeriodo / diasPeriodo;

    rodape.innerHTML = `
        <tr>
            <td>Período</td>
            <td>${formatarNumero(totalPeriodo, 1)}</td>
            <td>${formatarNumero(mediaPeriodo, 2)}</td>
            <td>${diasPeriodo}</td>
        </tr>
    `;

    return { totalPeriodo, diasPeriodo, mediaPeriodo };
}

// Gráfico de barras em HTML/CSS: uma coluna por mês.
function renderizarGrafico(tabela) {
    const grafico = document.getElementById("grafico");
    const legenda = document.getElementById("graficoLegenda");

    if (tabela.length === 0) {
        grafico.innerHTML = "";
        legenda.innerHTML = "";
        return;
    }

    const maximo = Math.max(...tabela.map(l => l.total));
    const multiAno = periodoTemVariosAnos(tabela);
    const { iMax, iMin } = indicesExtremos(tabela);
    const temExtremos = tabela.length > 1 && tabela[iMax].total !== tabela[iMin].total;

    grafico.innerHTML = tabela.map((linha, i) => {
        const altura = maximo > 0 ? (linha.total / maximo) * 100 : 0;
        const [ano, numero] = linha.mes.split("-");
        const abreviado = MESES[Number(numero) - 1];
        const rotulo = multiAno ? `${abreviado}/${ano.slice(2)}` : abreviado;

        let classe = "";
        if (temExtremos && i === iMax) classe = " mais-chuvoso";
        else if (temExtremos && i === iMin) classe = " mais-seco";

        return `
            <div class="coluna" title="${nomeMes(linha.mes)}: ${formatarNumero(linha.total, 1)} mm">
                <div class="barra-area">
                    <span class="valor">${Math.round(linha.total)}</span>
                    <div class="barra${classe}" style="height: ${altura}%"></div>
                </div>
                <span class="mes">
                    <span class="mes-cheio">${rotulo}</span><span class="mes-inicial">${abreviado[0]}</span>
                </span>
            </div>
        `;
    }).join("");

    if (temExtremos) {
        legenda.innerHTML = `
            <span><span class="chave chave-chuvoso"></span>Mais chuvoso: ${nomeMesLongo(tabela[iMax].mes, multiAno)} (${Math.round(tabela[iMax].total)} mm)</span>
            <span><span class="chave chave-seco"></span>Mais seco: ${nomeMesLongo(tabela[iMin].mes, multiAno)} (${Math.round(tabela[iMin].total)} mm)</span>
        `;
    } else {
        legenda.innerHTML = "";
    }
}

function montarFrase(nome, tabela, totais, inicio, fim) {
    if (!totais) {
        return "Não há dados de chuva para este município no período escolhido.";
    }

    const total = formatarNumero(totais.totalPeriodo, 0);
    let frase = `Em ${nome}, choveu cerca de ${total} mm entre ${formatarDataBR(inicio)} e ${formatarDataBR(fim)}.`;

    if (tabela.length > 1) {
        const { iMax, iMin } = indicesExtremos(tabela);

        if (tabela[iMax].total !== tabela[iMin].total) {
            const multiAno = periodoTemVariosAnos(tabela);

            frase +=
                ` O mês mais chuvoso foi ${nomeMesLongo(tabela[iMax].mes, multiAno)} ` +
                `(${Math.round(tabela[iMax].total)} mm) e o mais seco, ` +
                `${nomeMesLongo(tabela[iMin].mes, multiAno)} (${Math.round(tabela[iMin].total)} mm).`;
        }
    }

    return frase;
}

async function mostrarTabelaMunicipio(mun) {
    const frase = document.getElementById("cidadeFrase");
    const origem = document.getElementById("cidadeOrigem");
    const periodoEl = document.getElementById("cidadePeriodo");

    document.getElementById("cidadeTitulo").textContent = mun.nome;
    frase.textContent = "Carregando dados...";
    origem.textContent = "";
    periodoEl.textContent = "";
    limparTabelaMensal();
    reiniciarAnaliseIA();

    try {
        await carregarDadosGrade();
    } catch (erro) {
        console.error("Erro ao carregar precipitacao_grade.json:", erro);
        frase.textContent = ABERTO_POR_ARQUIVO
            ? `Os dados de chuva não carregam quando a página é aberta como arquivo. ${AJUDA_SERVIDOR}`
            : "Não foi possível carregar os dados de chuva (precipitacao_grade.json). Veja o console (F12).";
        return;
    }

    
    if (municipioSelecionado !== mun) return;

    const { inicio, fim } = lerPeriodo();

    if (!inicio || !fim || inicio > fim) {
        frase.textContent = "Escolha um período válido: a data inicial deve vir antes da final.";
        return;
    }

    usouDataFallback = false;

    const selecao = escolherPontos(mun);
    const tabela = tabelaMensal(selecao.pontos, inicio, fim);
    const totais = renderizarTabelaMensal(tabela);

    renderizarGrafico(tabela);
    frase.textContent = montarFrase(mun.nome, tabela, totais, inicio, fim);
    periodoEl.textContent = `Período: ${formatarDataBR(inicio)} a ${formatarDataBR(fim)}.`;

    let textoOrigem;

    if (selecao.metodo === "dentro") {
        const n = selecao.pontos.length;
        textoOrigem = n === 1
            ? "Estimativa a partir de 1 ponto de medição dentro do município."
            : `Estimativa a partir da média de ${n} pontos de medição dentro do município.`;
    } else if (selecao.ponto) {
        textoOrigem =
            "Este município é pequeno demais para ter um ponto de medição dentro dele. " +
            `Usamos o ponto mais próximo, a ${formatarNumero(selecao.distanciaKm, 1)} km do centro.`;
    } else {
        textoOrigem = "Nenhum ponto de medição disponível.";
    }

    if (usouDataFallback) {
        textoOrigem += ` Atenção: o JSON não traz data por dia; assumi que começa em ${DATA_INICIAL_JSON}.`;
    }

    origem.textContent = textoOrigem;

    // resumo guardado para o LLM
    ultimoResumoCidade = {
        municipio: mun.nome,
        codigoIbge: mun.codigo,
        periodo: { inicio, fim },
        origemDados: selecao.metodo === "dentro"
            ? { metodo: "pontos_dentro_do_municipio", quantidade: selecao.pontos.length }
            : {
                metodo: "ponto_mais_proximo",
                lat: selecao.ponto?.lat ?? null,
                lon: selecao.ponto?.lon ?? null,
                distanciaKm: selecao.distanciaKm
            },
        mensal: tabela,
        totais
    };

    if (tabela.length > 0) {
        document.getElementById("analisarIA").disabled = false;
    }
}

function selecionarMunicipio(codigo) {
    const mun = municipios.find(m => m.codigo === codigo);
    if (!mun) return;

    document.getElementById("municipio").value = mun.nome;

    destacarMunicipio(mun);
    mostrarFicha();
    map.fitBounds(mun.layer.getBounds(), { maxZoom: 10 });

    // no celular a ficha fica abaixo do mapa: leva a pessoa até ela
    if (window.matchMedia("(max-width: 900px)").matches) {
        document.getElementById("ficha").scrollIntoView({ behavior: "smooth", block: "start" });
    }

    mostrarTabelaMunicipio(mun);
    calcularRiscoDeslizamento(mun);
}

// Seleciona quando o texto digitado/escolhido coincide com um município.
function aoDigitarMunicipio(evento) {
    const chave = semAcento(evento.target.value);
    if (!chave) return;

    const mun = municipios.find(m => m.chave === chave);

    if (mun && mun !== municipioSelecionado) {
        selecionarMunicipio(mun.codigo);
    }
}


// ================================================================
// RISCO DE DESLIZAMENTO - MACHINE LEARNING
// ================================================================
function reiniciarRiscoDeslizamento() {
    const card = document.getElementById("riscoDeslizamento");
    if (!card) return;

    card.hidden = true;
    document.getElementById("riscoNivel").textContent = "--";
    document.getElementById("riscoMensagem").textContent = "Calculando...";
    document.getElementById("riscoProbabilidade").textContent = "--";
    document.getElementById("riscoChuva1").textContent = "--";
    document.getElementById("riscoChuva7").textContent = "--";
    document.getElementById("riscoChuva14").textContent = "--";
    document.getElementById("riscoAviso").textContent = "";
}

async function calcularRiscoDeslizamento(mun) {
    const card = document.getElementById("riscoDeslizamento");
    if (!card || !mun || !mun.centroide) return;

    reiniciarRiscoDeslizamento();
    card.hidden = false;
    document.getElementById("riscoMensagem").textContent = "Consultando a chuva e executando o modelo...";

    const { fim } = lerPeriodo();

    if (!fim) {
        document.getElementById("riscoMensagem").textContent =
            "Escolha uma data final válida para calcular a estimativa.";
        return;
    }

    const lat = mun.centroide.lat;
    const lon = mun.centroide.lon;

    try {
        const params = new URLSearchParams({
            lat: String(lat),
            lon: String(lon),
            date: fim
        });

        const resposta = await fetch(`${API_URL}/predict_risk?${params.toString()}`);

        // erro do servidor pode vir sem JSON (ex.: "Internal Server Error")
        let dados = null;
        try { dados = await resposta.json(); } catch (_) { /* corpo vazio ou texto */ }

        if (!resposta.ok || !dados || dados.mensagem) {
            throw new Error(
                (dados && dados.mensagem) ||
                `a API respondeu com erro (HTTP ${resposta.status}). Veja o terminal onde o uvicorn está rodando.`
            );
        }

        const prob = Number(dados.landslide_probability_percent);
        const nivel = String(dados.risk_level || "indisponível");

        document.getElementById("riscoNivel").textContent =
            nivel.charAt(0).toUpperCase() + nivel.slice(1);

        document.getElementById("riscoProbabilidade").textContent =
            `${prob.toFixed(1)}%`;

        document.getElementById("riscoChuva1").textContent =
            `${Number(dados.precipitation_1d).toFixed(1)} mm`;

        document.getElementById("riscoChuva7").textContent =
            `${Number(dados.precipitation_7d).toFixed(1)} mm`;

        document.getElementById("riscoChuva14").textContent =
            `${Number(dados.precipitation_14d).toFixed(1)} mm`;

        document.getElementById("riscoMensagem").textContent =
            `Para ${mun.nome}, com base na chuva dos 14 dias anteriores a ${formatarDataBR(fim)}, o modelo estimou ${prob.toFixed(1)}% de probabilidade de deslizamento.`;

        document.getElementById("riscoAviso").textContent = dados.disclaimer || "";
        card.dataset.nivel = nivel;
    } catch (erro) {
        console.error("Erro ao calcular risco de deslizamento:", erro);
        const apiForaDoAr = erro instanceof TypeError;  // fetch falhou: sem conexão com a API
        document.getElementById("riscoNivel").textContent = "Indisponível";
        document.getElementById("riscoMensagem").textContent = apiForaDoAr
            ? `Não consegui falar com a API em ${API_URL}. ${AJUDA_SERVIDOR}`
            : `Não foi possível calcular o risco: ${erro.message}`;
        document.getElementById("riscoAviso").textContent = "";
    }
}

// ANÁLISE COM LLM (Groq)
function reiniciarAnaliseIA() {
    if (controladorIA) {
        controladorIA.abort();
        controladorIA = null;
    }

    ultimoResumoCidade = null;
    document.getElementById("analisarIA").disabled = true;
    document.getElementById("analiseIA").textContent = "";
    document.getElementById("avisoIA").hidden = true;
}

function montarMensagensCidade(resumo) {
    const linhasMeses = resumo.mensal
        .map(l =>
            `${nomeMes(l.mes)}: total ${l.total.toFixed(1)} mm, ` +
            `média ${l.mediaDiaria.toFixed(2)} mm/dia, ${l.dias} dias com dado`
        )
        .join("\n");

    let origem;

    if (resumo.origemDados.metodo === "pontos_dentro_do_municipio") {
        origem =
            `média de ${resumo.origemDados.quantidade} ponto(s) de uma grade de baixa resolução ` +
            "que ficam dentro do município";
    } else {
        origem =
            "o município é pequeno demais e não contém nenhum ponto da grade; " +
            `foi usado o ponto mais próximo, a ${resumo.origemDados.distanciaKm.toFixed(1)} km do centro do município`;
    }

    const sistema = "Você é um comunicador e analista de dados climáticos. Responda em português do Brasil " +
    "com um tom acessível, amigável e fácil de entender para moradores locais (público não técnico). " +
    "REQUISITO CRUCIAL DE FORMATAÇÃO: Responda em exatamente três parágrafos de texto puro e corrido. " +
    "É estritamente proibido usar markdown, negrito, tabelas, listas, asteriscos ou símbolos de cabeçalho. " +
    "Use apenas os dados fornecidos e nunca invente números.";
    
    const usuario = `Analise a chuva no município de ${resumo.municipio} (SP) para os nossos moradores.\n\n` +
    `Período: ${formatarDataBR(resumo.periodo.inicio)} a ${formatarDataBR(resumo.periodo.fim)}.\n` +
    `Origem dos dados: ${origem}.\n\n` +
    "Dados de chuva por mês:\n" +
    `${linhasMeses}\n\n` +
    `Total acumulado: ${resumo.totais.totalPeriodo.toFixed(1)} mm em ${resumo.totais.diasPeriodo} dias ` +
    `(média de ${resumo.totais.mediaPeriodo.toFixed(2)} mm por dia).\n\n` +
    "Escreva um texto de exatamente três parágrafos seguindo este roteiro:\n" +
    "No primeiro parágrafo, apresente o volume total de chuva na cidade de forma simples e destaque quais foram os meses mais impactados pela chuva e os períodos mais secos, citando os valores.\n" +
    "No segundo parágrafo, explique como o ritmo da chuva mudou ao longo dos meses, apontando se o clima seguiu o padrão esperado de estações e da localização geográfica da cidade ou se houve alguma surpresa, como chuva muito concentrada ou falha de dados em algum mês.\n" +
    "No terceiro parágrafo, faça uma comparação contextualizando o comportamento da chuva em relação a outras cidades paulistas (se choveu mais ou menos que a média do estado), e termine com uma mensagem de interesse para quem vive no município (como riscos de enchentes, queimadas, possibilidades de atividades ao ar livre, entre outras, estudando o histórico destes fenomenos nas cidades).\n";

    return [
        { role: "system", content: sistema },
        { role: "user", content: usuario }
    ];
}

async function analisarCidadeComIA() {
    const saida = document.getElementById("analiseIA");
    const botao = document.getElementById("analisarIA");
    const aviso = document.getElementById("avisoIA");
    const resumo = ultimoResumoCidade;

    if (!resumo || resumo.mensal.length === 0) {
        saida.textContent = "Selecione um município com dados para gerar a explicação.";
        return;
    }

    if (!GROQ_API_KEY || GROQ_API_KEY === "COLE_SUA_CHAVE_AQUI") {
        saida.textContent = "Defina a constante GROQ_API_KEY no topo do script.js.";
        return;
    }

    if (controladorIA) {
        controladorIA.abort();
    }

    const controlador = new AbortController();
    controladorIA = controlador;

    botao.disabled = true;
    saida.textContent = "Analisando...";
    aviso.hidden = true;

    try {
        const resposta = await fetch(GROQ_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${GROQ_API_KEY}`
            },
            body: JSON.stringify({
                model: GROQ_MODELO,
                messages: montarMensagensCidade(resumo),
                temperature: 1,
                max_completion_tokens: 2048,
                top_p: 1,
                reasoning_effort: "medium",
                stream: true,
                stop: null
            }),
            signal: controlador.signal
        });

        if (!resposta.ok) {
            throw new Error(`${resposta.status} - ${await resposta.text()}`);
        }

        const leitor = resposta.body.getReader();
        const decodificador = new TextDecoder();
        let buffer = "";
        let texto = "";

        while (true) {
            const { done, value } = await leitor.read();
            if (done) break;

            buffer += decodificador.decode(value, { stream: true });

            const linhas = buffer.split("\n");
            buffer = linhas.pop(); 

            for (const linha of linhas) {
                const conteudo = linha.trim();

                if (!conteudo.startsWith("data:")) continue;

                const dados = conteudo.slice(5).trim();
                if (dados === "[DONE]") continue;

                try {
                    const trecho = JSON.parse(dados).choices?.[0]?.delta?.content;

                    if (trecho) {
                        texto += trecho;
                        saida.textContent = texto;
                    }
                } catch (erroJson) {
                    // ignora chunk malformado
                }
            }
        }

        if (texto) {
            aviso.hidden = false;
        } else {
            saida.textContent = "O modelo não retornou texto. Tente novamente.";
        }

    } catch (erro) {
        if (erro.name === "AbortError") return;

        console.error("Erro na análise com IA:", erro);
        saida.textContent = `Erro ao consultar a IA: ${erro.message}`;

    } finally {
        if (controladorIA === controlador) {
            controladorIA = null;
            botao.disabled = false;
        }
    }
}

// BUSCAR (mapa de calor do estado)
async function buscarGrade(evento) {
    if (evento) {
        evento.preventDefault();
    }

    const status = document.getElementById("status");
    const { inicio, fim } = lerPeriodo();

    if (!inicio || !fim) {
        status.textContent = "Informe as duas datas.";
        return;
    }

    if (inicio > fim) {
        status.textContent = "A data inicial não pode ser maior que a data final.";
        return;
    }

    status.textContent = "Carregando o mapa...";
    await garantirLimiteSP();

    if (!limiteSP) {
        status.textContent = "Não foi possível carregar o contorno do estado. Tente recarregar a página.";
        return;
    }

    try {
        await carregarDadosGrade();
    } catch (erro) {
        console.error(
            "Erro ao carregar precipitacao_grade.json. " +
            "Abra a página por um servidor HTTP (ex.: python -m http.server).",
            erro
        );
        status.textContent = ABERTO_POR_ARQUIVO
            ? `Os dados de chuva não carregam quando a página é aberta como arquivo. ${AJUDA_SERVIDOR}`
            : "Não foi possível carregar os dados de chuva (precipitacao_grade.json). Veja o console (F12).";
        return;
    }

    const resultados = [];

    for (const item of dadosGrade.pontos) {
        const mediaDiaria = calcularMediaDiaria(item, inicio, fim);

        if (mediaDiaria !== null) {
            resultados.push({
                lat: item.lat,
                lon: item.lon,
                precipitation: mediaDiaria
            });
        }
    }

    if (resultados.length === 0) {
        status.textContent = "Não há dados de chuva no período escolhido.";
        return;
    }

    status.textContent = "Calculando o mapa de chuva...";

    // deixa o navegador atualizar o texto antes do cálculo pesado
    await new Promise(resolve => setTimeout(resolve, 0));

    const { matriz, nLat, nLon } = gerarMatrizInterpolada(resultados);
    const { min, max } = renderizarRaster(matriz, nLat, nLon);

    atualizarLegenda(min, max);

    status.textContent =
        `Média diária de chuva entre ${formatarDataBR(inicio)} e ${formatarDataBR(fim)}. ` +
        "Passe o mouse ou toque em um município para ver o nome.";

    // se há município aberto, atualiza a ficha para o novo período
    if (municipioSelecionado) {
        mostrarTabelaMunicipio(municipioSelecionado);
        calcularRiscoDeslizamento(municipioSelecionado);
    }
}

//INICIALIZAÇÃO

document.getElementById("analisarIA").addEventListener("click", analisarCidadeComIA);
document.getElementById("buscar").addEventListener("click", buscarGrade);
document.getElementById("municipio").addEventListener("input", aoDigitarMunicipio);
document.getElementById("fecharCidade").addEventListener("click", limparSelecaoMunicipio);

carregarLimitesMunicipios();
buscarGrade();